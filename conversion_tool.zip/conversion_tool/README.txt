Required installs for this script to run:

pytesseract
pdf2image
poppler
